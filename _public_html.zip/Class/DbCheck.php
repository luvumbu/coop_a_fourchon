<?php 
$dbname = "root";
$username = "root";
$admin_id_sha1_user  = "1734440150";
?>
