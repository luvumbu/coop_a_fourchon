<?php  
session_start() ; 

?>